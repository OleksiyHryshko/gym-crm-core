package org.example.dto.request;

import jakarta.validation.constraints.NotBlank;

public record TrainerRegistrationRequest (
        @NotBlank(message = "First name is required") String firstName,
        @NotBlank(message = "Last name is required") String lastName,
        @NotBlank(message = "Specialization is required") String specialization
) {}
